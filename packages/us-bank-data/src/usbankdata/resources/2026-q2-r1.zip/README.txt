BanksOnSale Data | 2026-q2-r1
Report date: 2026-06-30
Retrieved: 2026-10-21T15:16:52.221456Z
Publisher: BanksOnSale (https://www.banksonsale.com)
Original source: FDIC BankFind Suite, financials endpoint.
Source field definitions: https://api.fdic.gov/banks/docs/risview_properties.yaml
Monetary values are USD THOUSANDS. Ratios are already PERCENT.
Empty CSV cells and JSON null mean missing, never zero.
CERT identifies the institution, not its holding company or ticker.
All source classes are retained, including noninsured institutions (NC) and insured foreign branches (OI); see bank_class and manifest.json.
Scope and per-field coverage: manifest.json. Source responses and SHA-256 hashes retained.
License: CC BY 4.0 for BanksOnSale compilation and original metadata.
Credit: BanksOnSale Data, sourced from FDIC BankFind Suite, 2026-06-30, 2026-q2-r1.
Not affiliated with or endorsed by FDIC. Research only; not confirmed sale listings.
Corrections: https://www.banksonsale.com/corrections
